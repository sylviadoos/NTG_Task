package com.ntgclarity.currencyconverter.views.currencyList

import org.testng.Assert.*

import org.testng.annotations.Test

class CurrencyViewModelTest {

    @Test
    fun testGet_currencyCodes() {
    }

    @Test
    fun testGetCurrencyCodes() {
    }

    @Test
    fun testGetAfterConvertAmount() {
    }

    @Test
    fun testFetchCurrencyCodes() {
    }

    @Test
    fun testConvertAmount() {
    }
}