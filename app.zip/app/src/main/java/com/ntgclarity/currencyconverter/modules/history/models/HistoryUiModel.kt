package com.ntgclarity.currencyconverter.modules.history.models

data class HistoryUiModel (val dateConvert: String, val convertData : String)