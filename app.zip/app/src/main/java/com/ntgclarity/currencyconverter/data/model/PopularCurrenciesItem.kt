package com.ntgclarity.currencyconverter.data.model

data class PopularCurrenciesItem(
    val otherCurrency: String,
    val rate: String
)