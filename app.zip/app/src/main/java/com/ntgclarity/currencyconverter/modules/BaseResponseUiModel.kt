package com.ntgclarity.currencyconverter.modules

class BaseResponseUiModel <T>(val isSuccessful :Boolean,val message:String,val data :T?)
