package com.ntgclarity.currencyconverter.modules.popularCurrencies.models

class OtherPopularCurrencyUiModel (val name:String,val rate:String,val base:String){

}
